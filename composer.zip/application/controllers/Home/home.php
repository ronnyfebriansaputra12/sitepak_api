<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
    function login(){
        $input_data =file_get_contents('php://input');
		$data_post=json_decode($input_data, true);
		$hasil=[];
		$user=User_sitepak_model::get_criteria(array("select"=>"nik, nama, no_kk, kec, kel, no_hp, email, status, get_nama_kec(kec) nama_kec, get_nama_kel(kec,kel) nama_kel, path_kk","where"=>array("NIK" =>$data_post['LOGIN']["NIK"],"PASSWORD"=>md5($data_post['LOGIN']["PASSWORD"]))));
		$numRecords = count($user);
		if($numRecords ==0){
			//$hasil = "NIK sudah terdaftar";
			$hasil = '{"pesan":"User Atau Password Tidak Valid"}';
			$this->output->set_content_type('application/json')->set_output($hasil);
		}else{
			//$user = User_sitepak_model::get_criteria([,"where"=>["NIK" =>$data_post['LOGIN']["NIK"],"PASSWORD"=>md5($data_post['LOGIN']["PASSWORD"])],]);
			if($user[0]->status!=1){
				$hasil = '{"pesan":"User Anda Tidak Aktif"}';
				$this->output->set_content_type('application/json')->set_output($hasil);
			}else{
				$hasil = $user[0];
				$this->output->set_content_type('application/json')->set_output($hasil->to_json());
			}
		}
    }
	
	
    
}