<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BiodataWni extends CI_Controller {
    function get_anggota_keluarga($no_kk){
        $SEL = "B.NO_KK, B.NIK, B.NAMA_LGKP,
            B.TMPT_LHR, TO_CHAR(B.TGL_LHR, 'DD-MM-YYYY') AS TGLLHR,
            B.JENIS_KLMIN, DECODE (B.JENIS_KLMIN,  1, 'LAKI-LAKI',  2, 'PEREMPUAN') JK,
            B.STAT_KWN, UPPER (f5_get_ref_wni (stat_kwn, 601)) STAT_KWIN,
            B.PDDK_AKH, UPPER (f5_get_ref_wni (pddk_akh, 101)) PENDIDIKAN,
            B.AGAMA, UPPER (f5_get_ref_wni (f5_to_number (agama, 7), 501)) DAGAMA,
            B.JENIS_PKRJN, UPPER (f5_get_ref_wni (jenis_pkrjn, 201)) PEKERJAAN,
            B.GOL_DRH, UPPER (f5_get_ref_wni (f5_to_number (gol_drh, 7), 401)) GOLDRH,
            B.STAT_HBKEL, UPPER (f5_get_ref_wni (stat_hbkel, 301)) HBKEL,
            B.NO_PROP, B.NO_KAB, B.NO_KEC, B.NO_KEL,
            B.NAMA_LGKP_IBU, B.NAMA_LGKP_AYAH,
            getnamaprop(B.NO_PROP) AS PROP,
            getnamakab(B.NO_KAB, B.NO_PROP) AS KAB,
            getnamakec(B.NO_KEC, B.NO_KAB, B.NO_PROP) AS KEC_NAME,
            getnamakel(B.NO_KEL, B.NO_KEC, B.NO_KAB, B.NO_PROP) AS KEL_NAME";
        $all = Biodata_wni_model::get_criteria(["select"=>$SEL,
            "where"=>["NO_KK"=>$no_kk,"FLAG_STATUS"=>"0"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil));
    }
    function get_anggota_biodata($no_kk){
        $SEL = "B.NO_KK, B.NIK, B.NAMA_LGKP,
            B.TMPT_LHR, TO_CHAR(B.TGL_LHR, 'DD-MM-YYYY') AS TGLLHR,
            B.JENIS_KLMIN, DECODE (B.JENIS_KLMIN,  1, 'LAKI-LAKI',  2, 'PEREMPUAN') JK,
            B.STAT_KWN, UPPER (f5_get_ref_wni (stat_kwn, 601)) STAT_KWIN,
            B.PDDK_AKH, UPPER (f5_get_ref_wni (pddk_akh, 101)) PENDIDIKAN,
            B.AGAMA, UPPER (f5_get_ref_wni (f5_to_number (agama, 7), 501)) DAGAMA,
            B.JENIS_PKRJN, UPPER (f5_get_ref_wni (jenis_pkrjn, 201)) PEKERJAAN,
            B.GOL_DRH, UPPER (f5_get_ref_wni (f5_to_number (gol_drh, 7), 401)) GOLDRH,
            B.STAT_HBKEL, UPPER (f5_get_ref_wni (stat_hbkel, 301)) HBKEL,
            B.NO_PROP, B.NO_KAB, B.NO_KEC, B.NO_KEL,
            B.NAMA_LGKP_IBU, B.NAMA_LGKP_AYAH,
            getnamaprop(B.NO_PROP) AS PROP_NAME,
            getnamakab(B.NO_KAB, B.NO_PROP) AS KAB_NAME,
            getnamakec(B.NO_KEC, B.NO_KAB, B.NO_PROP) AS KEC_NAME,
            getnamakel(B.NO_KEL, B.NO_KEC, B.NO_KAB, B.NO_PROP) AS KEL_NAME";
        $all = Biodata_wni_model::get_criteria(["select"=>$SEL,
            "where"=>["NO_KK"=>$no_kk,"FLAG_STATUS"=>"0"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil));
    }
	
	public function get_biodata($nik){
		$SEL="	NO_KK, NIK, NAMA_LGKP,
				TMPT_LHR, TO_CHAR(TGL_LHR, 'DD-MM-YYYY') AS TGLLHR,NO_AKTA_LHR,
				JENIS_KLMIN, DECODE (JENIS_KLMIN,  1, 'LAKI-LAKI',  2, 'PEREMPUAN') JK,
				STAT_KWN, UPPER (f5_get_ref_wni (stat_kwn, 601)) STAT_KWIN,
				PDDK_AKH, UPPER (f5_get_ref_wni (pddk_akh, 101)) PENDIDIKAN,
				AGAMA, UPPER (f5_get_ref_wni (f5_to_number (agama, 7), 501)) DAGAMA,
				JENIS_PKRJN, UPPER (f5_get_ref_wni (jenis_pkrjn, 201)) PEKERJAAN,
				GOL_DRH, UPPER (f5_get_ref_wni (f5_to_number (gol_drh, 7), 401)) GOLDRH,
				STAT_HBKEL, UPPER (f5_get_ref_wni (stat_hbkel, 301)) HBKEL,
				NO_PROP, NO_KAB, NO_KEC, NO_KEL,NO_AKTA_KWN,TGL_KWN,
				NAMA_LGKP_IBU, NAMA_LGKP_AYAH,NIK_IBU,
				getnamaprop(NO_PROP) AS PROP,
				getnamakab(NO_KAB, NO_PROP) AS KAB,
				getnamakec(NO_KEC, NO_KAB, NO_PROP) AS KEC_NAME,
				getnamakel(NO_KEL, NO_KEC, NO_KAB, NO_PROP) AS KEL_NAME";
		$all = Biodata_wni_model::get_criteria(["select"=>$SEL,
            "where"=>["NIK"=>$nik,"FLAG_STATUS"=>"0"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil[0]));
	}
	
	public function get_anggota_biodata_row($no_kk){
		$SEL ="	NO_KK, NIK, NAMA_LGKP,
				TMPT_LHR, TO_CHAR(TGL_LHR, 'DD-MM-YYYY') AS TGLLHR,
				JENIS_KLMIN, DECODE (JENIS_KLMIN,  1, 'LAKI-LAKI',  2, 'PEREMPUAN') JK,
				STAT_KWN, UPPER (f5_get_ref_wni (stat_kwn, 601)) STAT_KWIN,
				PDDK_AKH, UPPER (f5_get_ref_wni (pddk_akh, 101)) PENDIDIKAN,
				AGAMA, UPPER (f5_get_ref_wni (f5_to_number (agama, 7), 501)) DAGAMA,
				JENIS_PKRJN, UPPER (f5_get_ref_wni (jenis_pkrjn, 201)) PEKERJAAN,
				GOL_DRH, UPPER (f5_get_ref_wni (f5_to_number (gol_drh, 7), 401)) GOLDRH,
				STAT_HBKEL, UPPER (f5_get_ref_wni (stat_hbkel, 301)) HBKEL,
				NO_PROP, NO_KAB, NO_KEC, NO_KEL,
				NAMA_LGKP_IBU, NAMA_LGKP_AYAH,
				getnamaprop(NO_PROP) AS PROP_NAME,
				getnamakab(NO_KAB, NO_PROP) AS KAB_NAME,
				getnamakec(NO_KEC, NO_KAB, NO_PROP) AS KEC_NAME,
				getnamakel(NO_KEL, NO_KEC, NO_KAB, NO_PROP) AS KEL_NAME";
		$all = Biodata_wni_model::get_criteria(["select"=>$SEL,
            "where"=>["NO_KK"=>$no_kk,"FLAG_STATUS"=>"0"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil));
	}
	
	public function get_kepala_keluarga($no_kk){
		$all = Biodata_wni_model::get_criteria([
            "where"=>["NO_KK"=>$no_kk,"FLAG_STATUS"=>"0","STAT_HBKEL"=>"1"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil));
	}
	
	public function get_ibu($no_kk,$nik){
		
		$all = Biodata_wni_model::get_criteria([
            "where"=>["NO_KK"=>$no_kk,"NIK"=>$nik,"FLAG_STATUS"=>"0"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
		//print_r(count($all));
		if(count($all)==1){
			foreach($all as $dataBiodata){
				$hasilSatuan=$dataBiodata->to_array();
				$hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
			}
			$this->output->set_content_type('application/json')
				->set_output(json_encode($hasil));
		}else{
			$test=array("NO_AKTA_KWN"=>"","TGL_KWN"=>"");
			$hasil[]=array_change_key_case($test,CASE_UPPER);
			$this->output->set_content_type('application/json')
				->set_output(json_encode($hasil));
		}
        
	}
	
	public function check_nik_nkk($nik,$no_kk){
		$SEL="NIK";
		$all = Biodata_wni_model::get_criteria(["select"=>$SEL,
            "where"=>["NO_KK"=>$no_kk,"NIK"=>$nik,"FLAG_STATUS"=>"0"],
            "from"=>"BIODATA_WNI B",
            "order"=>"TGL_LHR ASC"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil));
	}
	
	 function update_akta_lahir($nik, $no_akta){
		$updateData = array("NO_AKTA_LHR"=>$no_akta,"AKTA_LHR"=>2);
		$paramData= array("NIK"=>$nik);
		Biodata_wni_model::table()->update($updateData,$paramData);
		
    }
}