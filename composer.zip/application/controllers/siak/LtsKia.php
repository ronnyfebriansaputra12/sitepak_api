<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LtsKia extends CI_Controller {
    function register_kia(){
		$nik = $_GET['NIK'];
		$by = $_GET['CREATED_BY'];
		$all = Lts_kia_model::get_criteria([
            "where"=>["NIK"=>$nik],
            "from"=>"LTS_KIA"]);
       if(count($all)>0){
			$updateData = array("EXPIRED_STATUS"=>"N");
			$paramData= array("NIK"=>$nik);
			Lts_kia_model::table()->update($updateData,$paramData);
			return true;
	   }else{
		    $tgl = date('d-m-Y h:i');
			$data = array();
			$data["NIK"]=$nik;
			$data["CREATED_BY"]=$by;
			$data["CREATED_DATE"] = $tgl;
			$data["EXPIRED_STATUS"] = "N";
			$new =new Lts_kia_model($data);
			$affected_row =$new->save();
			return true;
	   }
      
		
	}	
    
}