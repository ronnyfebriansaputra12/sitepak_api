<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DataKeluarga extends CI_Controller {
    function get_nik_orang_tua($no_kk){
        $SEL = "NIK_KK";
        $all = Data_keluarga_model::get_criteria(["select"=>$SEL,
            "where"=>["NO_KK"=>$no_kk],
            "from"=>"DATA_KELUARGA"]);
        $hasil=[];
        foreach($all as $dataBiodata){
            $hasilSatuan=$dataBiodata->to_array();
            $hasil[]=array_change_key_case($hasilSatuan,CASE_UPPER);
        }
        $this->output->set_content_type('application/json')
            ->set_output(json_encode($hasil));
    }
    
}