<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Kabupaten_model extends MY_Model {	
	static $table_name='setup_kab';
	static $primary_key=array('no_prop','no_kab');
}