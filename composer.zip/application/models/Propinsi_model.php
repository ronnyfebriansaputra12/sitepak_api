<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Propinsi_model extends MY_Model {	
	static $table_name='setup_prop';
	static $primary_key=array('no_prop');
}