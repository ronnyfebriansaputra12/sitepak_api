<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Base Site URL
|--------------------------------------------------------------------------
|
| URL to your CodeIgniter root. Typically this will be your base URL,
| WITH a trailing slash:
|
|	http://example.com/
|
| If this is not set then CodeIgniter will guess the protocol, domain and
| path to your installation.
|
*/
//$config['date_format_db']	= "Y-m-d";
$config['date_format_db']	= "d-m-Y";
$config['date_format_view'] = "d-m-Y";
$config['date_format'] = "Y-m-d";