<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config= [
    'default' => [
        'servers' => [
            [
                "host" => '172.16.5.125',
                "port" => 9200,
                'user' => '',
                'pass' => '',
                'scheme' => 'http',
            ]
        ],
        'index' => 'siak'
    ]
];