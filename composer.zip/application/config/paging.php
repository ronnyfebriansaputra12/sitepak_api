<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['paging_backend']	= 50;